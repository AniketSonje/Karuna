package com.app.KarunaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KarunaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(KarunaAppApplication.class, args);
	}

}
