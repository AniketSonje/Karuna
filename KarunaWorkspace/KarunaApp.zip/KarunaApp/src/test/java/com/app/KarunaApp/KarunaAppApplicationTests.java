package com.app.KarunaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KarunaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
